import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../models/image_models.dart';

class ImageList extends StatelessWidget{
  final List<ImageModel> images;

  ImageList(this.images);

  Widget build(cosntext){
    return MaterialApp();
  }
}