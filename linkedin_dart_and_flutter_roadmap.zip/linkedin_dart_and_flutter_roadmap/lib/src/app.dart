import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' show get;
import 'package:linkedin_dart_and_flutter_roadmap/src/models/image_models.dart';

class App extends StatefulWidget{
  createState(){
    return AppState();
  }
}

class AppState extends State<App>{
  int counter = 0;

  List<ImageModel> images = [];

  void fetchImage()async{
    counter +=1;
    var responds = await get('https://jsonplaceholder.typicode.com/photos/$counter' as Uri);
    var imageModel = ImageModel.fromJson(json.decode(responds.body));
    
    setState(() {
      images.add(imageModel);
    });
  }

  Widget build(context){
    return MaterialApp(
      home: Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: fetchImage,
          child: Icon(Icons.add),
        ),
        appBar: AppBar(
          title: Text('Heading'),
        ),
        body: Text('$counter'),
      ),
    );
  }
}