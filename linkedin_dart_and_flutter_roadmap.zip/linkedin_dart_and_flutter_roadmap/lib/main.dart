import 'package:flutter/material.dart';
import 'package:linkedin_dart_and_flutter_roadmap/src/app.dart';

void main(){
  // var app = MaterialApp(
  //   home: Scaffold(
  //     floatingActionButton: FloatingActionButton(
  //       onPressed: (){},
  //       child: Icon(Icons.add),
  //     ),
  //     appBar: AppBar(
  //       title: Text('Heading'),
  //     ),
  //   ),
  // );

  runApp(App());
}