package com.example.linkedin_dart_and_flutter_roadmap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
